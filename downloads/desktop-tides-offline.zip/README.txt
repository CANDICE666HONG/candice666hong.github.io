桌边潮汐 · 离线试玩 / Desktop Tides — Offline

1. 先把整个 ZIP 解压到桌面或常用文件夹。
2. 双击 Desktop-Tides.html，用 Chrome、Edge 或 Firefox 打开。
3. 游戏已经包含全部素材，不需要联网、安装软件或启动服务器。

昼夜默认跟随设备当地时间：06:00–18:00 为日光，其余为月夜。
点击海湾右上角的昼夜按钮，可以选择「自动 / 日光 / 月夜」。
鼠标左键框选水域后松开，随机放入一个生物；水波工具可以点击或拖动。
钓鱼时按住鼠标让绿色区域上升，松开下降。

图鉴和设置会尝试保存在当前浏览器。离线文件的保存方式取决于浏览器；
更换浏览器、移动或重命名 HTML、清理浏览器数据可能使旧记录不可用。
离线版与网站版的记录不会自动同步。

Unzip first, then double-click Desktop-Tides.html and open it in Chrome, Edge,
or Firefox. All artwork and code are included; no internet or local server is needed.
The game interface is Chinese and is designed for a mouse.
Day/night follows your device's local clock (06:00–18:00 is daytime), with an
Auto / Day / Night selector in the upper right.
Records are stored when the browser permits local-file storage. They are not synced
with the website. Changing browser, moving/renaming the file, or clearing browser
data can make old records unavailable.

作品集 / Portfolio: https://candicehong.cn/?lang=zh#desktop-tides
